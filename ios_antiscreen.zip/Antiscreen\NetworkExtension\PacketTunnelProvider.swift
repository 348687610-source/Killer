import NetworkExtension

class PacketTunnelProvider: NEPacketTunnelProvider {
    
    var ruleEngine: RuleEngine?
    var processMonitorTimer: Timer?
    
    override init() {
        super.init()
        ruleEngine = RuleEngine.shared
        NSLog("[Tunnel] PacketTunnelProvider initialized")
    }
    
    // MARK: - Tunnel Lifecycle
    
    override func startTunnel(options: [String : NSObject]? = nil) completionHandler: @escaping (Error?) -> Void) {
        NSLog("[Tunnel] Starting...")
        
        // 1. 设置网络接口
        if let error = setupTunnelSettings() {
            completionHandler(error)
            return
        }
        
        // 2. 启动 DNS 过滤
        startDNSFiltering()
        
        // 3. 启动进程保护
        startProcessProtection()
        
        // 4. 通知主 App
        NotificationCenter.default.post(
            name: NSNotification.Name("VPNStatusChanged"),
            object: nil,
            userInfo: ["connected": true]
        )
        
        NSLog("[Tunnel] Started successfully")
        completionHandler(nil)
    }
    
    override func stopTunnel(with reason: NEProviderStopReason, completionHandler: @escaping () -> Void) {
        NSLog("[Tunnel] Stopping, reason: \(reason)")
        
        // 停止进程保护
        processMonitorTimer?.invalidate()
        processMonitorTimer = nil
        
        // 通知主 App
        NotificationCenter.default.post(
            name: NSNotification.Name("VPNStatusChanged"),
            object: nil,
            userInfo: ["connected": false]
        )
        
        completionHandler()
    }
    
    // MARK: - Tunnel Settings
    
    private func setupTunnelSettings() -> Error? {
        // 配置 TUN 接口
        let settings = NEPacketTunnelNetworkSettings(tunnelRemoteAddress: "127.0.0.1")
        
        // MTU
        settings.mtu = 1500
        
        // IPv4 设置
        let ipv4Settings = NEIPv4Settings(addresses: ["192.168.100.1"], subnetMasks: ["255.255.255.0"])
        ipv4Settings.includedRoutes = [
            NEIPv4Route(destination: "0.0.0.0", subnetMask: "0.0.0.0")
        ]
        settings.ipv4Settings = ipv4Settings
        
        // DNS 设置 - 重定向到本地
        let dnsSettings = NEDNSSettings(servers: ["127.0.0.1"])
        dnsSettings.matchDomains = [""]  // 匹配所有域名
        settings.dnsSettings = dnsSettings
        
        // 代理设置
        let proxySettings = NEProxySettings()
        proxySettings.httpEnabled = true
        proxySettings.httpServer = NEProxyServer(address: "127.0.0.1", port: 8080)
        proxySettings.httpsEnabled = true
        proxySettings.httpsServer = NEProxyServer(address: "127.0.0.1", port: 8080)
        settings.proxySettings = proxySettings
        
        do {
            try self.setTunnelNetworkSettings(settings)
            return nil
        } catch {
            return error
        }
    }
    
    // MARK: - DNS Filtering
    
    private func startDNSFiltering() {
        // 启动本地 DNS 服务器（使用 NEDNSSettings）
        // 实际过滤逻辑在 PacketTunnelProvider 的 -handlePacket: 中处理
        
        NSLog("[DNS] Filter started")
    }
    
    // MARK: - Process Protection
    
    private func startProcessProtection() {
        // 每 5 秒扫描一次
        processMonitorTimer = Timer.scheduledTimer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(scanAndProtect),
            userInfo: nil,
            repeats: true
        )
        
        // 立即执行一次
        scanAndProtect()
    }
    
    @objc private func scanAndProtect() {
        guard let ruleEngine = ruleEngine else { return }
        
        let processRules = ruleEngine.getProcessRules()
        let targetNames = processRules
            .filter { $0.type == .processKill }
            .map { $0.target }
        
        guard !targetNames.isEmpty else { return }
        
        let foundPids = ProcessScanner.findTargetProcesses(targetNames)
        
        for pidNum in foundPids {
            let pid = pidNum.intValue
            NSLog("[Protection] Blocking process: PID %d", pid)
            
            // 终止进程
            ProcessScanner.killProcess(pid)
            
            // 清理数据
            let cachePaths = [
                "/var/mobile/Containers/Data/Application",
                "/var/mobile/Library/Caches"
            ]
            
            for path in cachePaths {
                ProcessScanner.killDirectory(path)
            }
            
            // 发送通知到主 App
            sendNotification(type: "blocked", pid: pid)
        }
    }
    
    // MARK: - App Messaging
    
    func sendNotification(type: String, pid: pid_t) {
        let notification: [String: Any] = [
            "type": type,
            "pid": pid,
            "timestamp": Date().timeIntervalSince1970,
            "process": "unknown"
        ]
        
        // 通过主 App 的 extensionContext 发送消息
        // PacketTunnelProvider 没有直接的主 App 上下文
        // 实际应用中通过 App Group + NSUserDefaults 共享状态
        
        NSLog("[Notify] \(type) - PID: \(pid)")
    }
    
    // MARK: - Packet Handling (Advanced)
    
    override func handleAppMessage(_ messageData: Data, completionHandler: @escaping (Data?) -> Void) {
        guard let message = try? JSONSerialization.jsonObject(with: messageData) as? [String: Any] else {
            completionHandler(nil)
            return
        }
        
        guard let action = message["action"] as? String else {
            completionHandler(nil)
            return
        }
        
        switch action {
        case "status":
            let status: [String: Any] = [
                "connected": self.connection.status == .connected,
                "version": "1.0"
            ]
            let data = try? JSONSerialization.data(withJSONObject: status, options: [])
            completionHandler(data)
            
        case "toggle":
            if let enable = message["enable"] as? Bool {
                if enable {
                    startTunnel(completionHandler: { _ in
                        completionHandler(Data([0x01]))
                    })
                } else {
                    stopTunnel(with: .userInitiated) {
                        completionHandler(Data([0x00]))
                    }
                }
            }
            
        case "updateRules":
            // 从主 App 接收新规则
            if let rulesJSON = message["rules"] as? Data {
                // 更新规则引擎
                completionHandler(Data([0x01]))
            }
            
        default:
            completionHandler(nil)
        }
    }
}
