# iOS 防观察 App (巨魔版)

从 Android 三款防观察软件逆向提取规则后，移植的 iOS 版本。

## 功能

### 已实现
- [x] NetworkExtension VPN 隧道
- [x] DNS 过滤 (对应 dns66)
- [x] 进程扫描与屏蔽 (对应 killPid/findPid)
- [x] 内存读写操作 (对应 peek/poke)
- [x] 反调试检测 (对应 antiDebug)
- [x] 进程注入 (对应 linjector)
- [x] 环境加固 (对应 hardenEnv)
- [x] 兼容 Android 规则格式

### 架构对应

| Android 功能 | iOS 实现 | 路径 |
|---|---|---|
| VPN 隧道 | `NEPacketTunnelProvider` | NetworkExtension/ |
| DNS 过滤 | `NEDNSSettings` + PacketTunnel | PacketTunnelProvider.swift |
| 进程扫描 | `kinfo_proc` / `proc_listpids` | ProcessScanner.m |
| 内存读写 | `task_for_pid` + `mach_vm_*` | ProcessScanner.m |
| 模块枚举 | `dyld_all_image_infos` | ProcessScanner.m |
| 进程注入 | `dlopen` / `mach_vm_write` | ProcessScanner.m |
| 反调试 | `PT_DENY_ATTACH` / `sysctl` | ProcessScanner.m |
| 规则导入 | AES-256-CBC + HMAC-SHA256 | RuleEngine.swift |

## 构建

### 1. 安装 Xcode 命令行工具
```bash
xcode-select --install
```

### 2. 使用 Xcode 构建

```bash
# 打开项目
open Antiscreen.xcodeproj

# 或使用 xcodebuild
xcodebuild -project Antiscreen.xcodeproj \
  -scheme Antiscreen \
  -configuration Release \
  -archivePath build/Antiscreen.xcarchive \
  archive

# 导出 IPA
xcodebuild -exportArchive \
  -archivePath build/Antiscreen.xcarchive \
  -exportOptionsPlist ExportOptions.plist \
  -exportPath build/
```

### 3. 使用构建脚本
```bash
chmod +x build.sh
./build.sh
```

### 4. 签名与安装

**巨魔版 (TrollStore):**
```bash
# 使用 ldid 签名
ldid -S build/Payload/Antiscreen.app/Antiscreen

# 打包 IPA
cd build && zip -qr ../Antiscreen.ipa Payload/
```

**AltStore / Sideloadly:**
```bash
# 使用个人证书签名
codesign -f -s "Apple Development" --entitlements Antiscreen.entitlements \
  build/Payload/Antiscreen.app/Antiscreen

# 打包 IPA
cd build && zip -qr ../Antiscreen.ipa Payload/
```

## 安装

### TrollStore (推荐)
1. 将 `Antiscreen.ipa` 发送到设备
2. 使用 TrollStore 安装

### AltStore
1. 用 AltStore 打开 IPA
2. 使用 Apple ID 签名安装

### 手动安装 (开发者模式)
1. 将 IPA 拖到 Xcode Devices
2. 或使用 `ios-deploy`:
```bash
ios-deploy --bundle Antiscreen.ipa
```

## 注意事项

### 权限要求
- **巨魔版**: 无需付费开发者账号，通过 TrollStore 签名
- **侧载版**: 需要 Apple Developer 账号
- **完全功能**: 需要越狱环境 (Substitute/ElleKit)

### 网络权限
- NetworkExtension 需要 VPN 权限
- 配置 VPN 后，所有流量经过 TUN 接口过滤
- DNS 过滤通过 `NEDNSSettings` 实现

### 进程注入限制
- iOS 15+: `task_for_pid` 需要 `com.apple.security.get-task-allow`
- 巨魔版可通过 Substitute/ElleKit 实现注入
- 非越狱环境仅支持进程监控，不支持注入

## 规则兼容性

此版本兼容 Android `librulecore` 导出的规则格式：

```json
{
  "rules": [
    {
      "type": "block",
      "target": "anticheatexpert.com",
      "port": 443
    },
    {
      "type": "process_kill",
      "target": "ace-guard"
    }
  ]
}
```

导入规则：
```swift
let key = Data(base64Encoded: "YOUR_RULE_KEY")!
let rules = Data(contentsOf: rulesFile)
RuleEngine.shared.importEncryptedRules(from: rules, key: key)
```

## 安全说明

本项目用于授权安全研究和授权对抗研究。请遵守当地法律法规，仅在授权环境下使用。

- 规则提取来自已授权样本
- 仅用于防御研究和授权分析
- 不用于破坏公平竞技或非法用途

当前:对象 / iOS 巨魔版防观察 / 工程骨架已完成
