import SwiftUI
import NetworkExtension

@main
struct AntiscreenApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    @StateObject private var vpnManager = NetworkManager.shared
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(vpnManager)
        }
    }
}

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        NetworkManager.shared.requestPermission()
        return true
    }
}

struct ContentView: View {
    @EnvironmentObject var vpnManager: NetworkManager
    @State private var isInjected = false
    @State private var logText = "等待启动..."
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                // Status Card
                StatusCard(status: vpnManager.connectionStatus, 
                          isProtected: vpnManager.isConnected)
                
                // Main Controls
                VStack(spacing: 12) {
                    Button(action: toggleVPN) {
                        HStack {
                            Image(systemName: vpnManager.isConnected ? "shield.slash.fill" : "shield.fill")
                            Text(vpnManager.isConnected ? "停止保护" : "启动防观察")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(vpnManager.isConnected ? Color.red : Color.green)
                        .cornerRadius(12)
                    }
                    
                    Button(action: injectTweak) {
                        HStack {
                            Image(systemName: "syringe.fill")
                            Text(isInjected ? "已注入" : "注入 Tweak")
                        }
                        .font(.headline)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(isInjected ? Color.gray : Color.blue)
                        .cornerRadius(12)
                    }
                    .disabled(isInjected)
                }
                
                // Process List
                VStack(alignment: .leading, spacing: 8) {
                    Text("进程保护")
                        .font(.headline)
                    
                    ForEach(vpnManager.protectedProcesses, id: \.self) { proc in
                        HStack {
                            Image(systemName: "checkmark.circle.fill")
                                .foregroundColor(.green)
                            Text(proc)
                            Spacer()
                        }
                    }
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                
                // Log
                ScrollView {
                    Text(logText)
                        .font(.system(.footnote, design: .monospaced))
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .frame(height: 150)
            }
            .padding()
            .navigationTitle("防观察")
        }
    }
    
    private func toggleVPN() {
        if vpnManager.isConnected {
            vpnManager.stopVPN { success in
                logText += "\n[$(Date())] VPN 已停止"
            }
        } else {
            vpnManager.startVPN { success in
                logText += success ? "\n[$(Date())] VPN 已启动" : "\n[$(Date())] VPN 启动失败"
            }
        }
    }
    
    private func injectTweak() {
        // Call native injector
        let result = ProcessScanner.injectTweak()
        isInjected = result
        logText += result ? "\n[$(Date())] Tweak 注入成功" : "\n[$(Date())] Tweak 注入失败"
    }
}

struct StatusCard: View {
    let status: NEVPNStatus
    let isProtected: Bool
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(isProtected ? "保护中" : "未保护")
                    .font(.title2)
                    .fontWeight(.bold)
                Text(statusDescription)
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Image(systemName: isProtected ? "shield.checkerboard" : "shield")
                .font(.system(size: 40))
                .foregroundColor(isProtected ? .green : .gray)
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(12)
        .shadow(radius: 2)
    }
    
    var statusDescription: String {
        switch status {
        case .invalid: return "无效配置"
        case .disconnected: return "已断开"
        case .connecting: return "连接中..."
        case .connected: return "已连接"
        case .reasserting: return "重新连接..."
        case .disconnecting: return "断开中..."
        @unknown default: return "未知"
        }
    }
}
