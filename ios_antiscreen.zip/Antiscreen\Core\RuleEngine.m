#import "RuleEngine.h"
#import <CommonCrypto/CommonCrypto.h>

@implementation Rule

- (instancetype)initWithName:(NSString *)name 
                       target:(NSString *)target 
                         type:(RuleType)type 
                         port:(NSNumber *)port {
    self = [super init];
    if (self) {
        _name = [name copy];
        _target = [target copy];
        _type = type;
        _port = [port copy];
    }
    return self;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"Rule{name=%@, target=%@, type=%ld, port=%@}", 
            self.name, self.target, (long)self.type, self.port];
}

@end

@implementation RuleEngine

+ (instancetype)shared {
    static RuleEngine *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[RuleEngine alloc] init];
        [instance loadDefaultRules];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _rules = [NSMutableArray array];
        _envelopeKey = nil;
    }
    return self;
}

- (void)loadDefaultRules {
    // 从 Android 提取的默认规则
    NSArray *defaultRules = @[
        // 网络过滤
        [[Rule alloc] initWithName:@"Block Anti-Cheat" 
                            target:@"anticheatexpert.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block Tencent Monitor" 
                            target:@"pingfore.qq.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block Valorant API" 
                            target:@"valorant-api.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block Riot Games" 
                            target:@"riotgames.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block Tencent Cloud" 
                            target:@"gcloud.tencent.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block QQ Monitor" 
                            target:@"mazu.3g.qq.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Block UU Accelerator" 
                            target:@"monitor.uu.qq.com" 
                              type:RuleTypeBlock 
                              port:@443],
        [[Rule alloc] initWithName:@"Redirect DNS" 
                            target:@"127.0.0.1" 
                              type:RuleTypeRedirect 
                              port:@53],
        
        // 进程屏蔽
        [[Rule alloc] initWithName:@"Block ACE Guard" 
                            target:@"ace-guard" 
                              type:RuleTypeProcessKill 
                              port:nil],
        [[Rule alloc] initWithName:@"Block Tenprotect" 
                            target:@"tenprotect" 
                              type:RuleTypeProcessKill 
                              port:nil],
        [[Rule alloc] initWithName:@"Block GameDetect" 
                            target:@"gamedetect" 
                              type:RuleTypeProcessKill 
                              port:nil],
        [[Rule alloc] initWithName:@"Block Observer" 
                            target:@"observer" 
                              type:RuleTypeProcessKill 
                              port:nil],
        
        // 内存保护
        [[Rule alloc] initWithName:@"Protect Anti-Cheat Memory" 
                            target:@"com.riotgames" 
                              type:RuleTypeMemoryProtect 
                              port:nil],
    ];
    
    [_rules addObjectsFromArray:defaultRules];
}

// 兼容 Android rulecore 的规则 envelope
// envelope 格式：[magic:4][version:2][encrypted_len:4][hmac:32][encrypted_payload:N]
static const uint32_t kEnvelopeMagic = 0xDEADBEEF;

- (BOOL)importEncryptedRulesFrom:(NSData *)data key:(NSData *)key {
    if (data.length < 40) return NO;
    
    // Parse envelope header
    const uint32_t *magic = (const uint32_t *)data.bytes;
    if (*magic != kEnvelopeMagic) return NO;
    
    // 版本 (2 bytes)
    uint16_t version;
    [data getBytes:&version range:NSMakeRange(4, 2)];
    
    // 加密长度 (4 bytes)
    uint32_t encryptedLen;
    [data getBytes:&encryptedLen range:NSMakeRange(6, 4)];
    
    if (encryptedLen == 0 || encryptedLen > data.length - 12 - 32) return NO;
    
    // 提取 HMAC 和加密载荷
    NSData *hmac = [data subdataWithRange:NSMakeRange(12 + encryptedLen, 32)];
    NSData *encryptedPayload = [data subdataWithRange:NSMakeRange(12, encryptedLen)];
    
    // 验证 HMAC
    NSData *computedHMAC = [self computeHMAC:encryptedPayload key:key];
    if (![hmac isEqualToData:computedHMAC]) return NO;
    
    // 解密 (AES-256-CBC)
    NSData *decrypted = [self decryptAES:encryptedPayload key:key];
    if (!decrypted) return NO;
    
    // 解析规则
    [self parseRulesFrom:decrypted];
    return YES;
}

- (NSData *)computeHMAC:(NSData *)data key:(NSData *)key {
    NSMutableData *mac = [NSMutableData dataWithLength:CC_SHA256_DIGEST_LENGTH];
    CCHmac(kCCHmacAlgSHA256, key.bytes, key.length, data.bytes, data.length, mac.mutableBytes);
    return mac;
}

- (NSData *)decryptAES:(NSData *)data key:(NSData *)key {
    NSMutableData *output = [NSMutableData dataWithLength:data.length + kCCBlockSizeAES128];
    size_t outLength = 0;
    
    // 使用前 16 字节作为 IV
    NSData *iv = [data subdataWithRange:NSMakeRange(0, kCCBlockSizeAES128)];
    NSData *ciphertext = [data subdataWithRange:NSMakeRange(kCCBlockSizeAES128, 
                                                             data.length - kCCBlockSizeAES128)];
    
    CCCryptorStatus status = CCCrypt(kCCDecrypt,
                                     kCCAlgorithmAES,
                                     kCCOptionPKCS7Padding,
                                     key.bytes,
                                     kCCKeySizeAES256,
                                     iv.bytes,
                                     ciphertext.bytes,
                                     ciphertext.length,
                                     output.mutableBytes,
                                     output.length,
                                     &outLength);
    
    if (status == kCCSuccess) {
        output.length = outLength;
        return output;
    }
    return nil;
}

- (void)parseRulesFrom:(NSData *)data {
    // 解析 JSON 格式的规则
    NSError *error;
    NSDictionary *json = [NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
    if (!json) {
        NSLog(@"[RuleEngine] Parse failed: %@", error);
        return;
    }
    
    NSArray *ruleArray = json[@"rules"];
    if (![ruleArray isKindOfClass:[NSArray class]]) return;
    
    NSMutableArray *newRules = [NSMutableArray array];
    
    for (NSDictionary *dict in ruleArray) {
        NSString *name = dict[@"name"];
        NSString *target = dict[@"target"];
        NSString *typeStr = dict[@"type"];
        NSNumber *port = dict[@"port"];
        
        if (!name || !target || !typeStr) continue;
        
        RuleType type;
        if ([typeStr isEqualToString:@"block"]) type = RuleTypeBlock;
        else if ([typeStr isEqualToString:@"redirect"]) type = RuleTypeRedirect;
        else if ([typeStr isEqualToString:@"process_kill"]) type = RuleTypeProcessKill;
        else if ([typeStr isEqualToString:@"memory_protect"]) type = RuleTypeMemoryProtect;
        else continue;
        
        Rule *rule = [[Rule alloc] initWithName:name target:target type:type port:port];
        [newRules addObject:rule];
    }
    
    if (newRules.count > 0) {
        [_rules removeAllObjects];
        [_rules addObjectsFromArray:newRules];
        NSLog(@"[RuleEngine] Loaded %lu rules", (unsigned long)_rules.count);
    }
}

- (void)importFromJSON:(NSString *)jsonString {
    NSData *data = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    [self parseRulesFrom:data];
}

- (NSData *)serializeRules {
    NSMutableArray *ruleDicts = [NSMutableArray array];
    
    for (Rule *rule in _rules) {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        dict[@"name"] = rule.name;
        dict[@"target"] = rule.target;
        
        switch (rule.type) {
            case RuleTypeBlock: dict[@"type"] = @"block"; break;
            case RuleTypeRedirect: dict[@"type"] = @"redirect"; break;
            case RuleTypeProcessKill: dict[@"type"] = @"process_kill"; break;
            case RuleTypeMemoryProtect: dict[@"type"] = @"memory_protect"; break;
        }
        
        if (rule.port) dict[@"port"] = rule.port;
        [ruleDicts addObject:dict];
    }
    
    NSDictionary *output = @{@"rules": ruleDicts};
    return [NSJSONSerialization dataWithJSONObject:output options:0 error:nil];
}

- (NSArray<Rule *> *)getNetworkRules {
    NSMutableArray *result = [NSMutableArray array];
    for (Rule *rule in _rules) {
        if (rule.type == RuleTypeBlock || rule.type == RuleTypeRedirect) {
            [result addObject:rule];
        }
    }
    return result;
}

- (NSArray<Rule *> *)getProcessRules {
    NSMutableArray *result = [NSMutableArray array];
    for (Rule *rule in _rules) {
        if (rule.type == RuleTypeProcessKill || rule.type == RuleTypeMemoryProtect) {
            [result addObject:rule];
        }
    }
    return result;
}

- (NSArray<Rule *> *)allRules {
    return [_rules copy];
}

@end
