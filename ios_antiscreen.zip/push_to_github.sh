#!/bin/bash
# Push to GitHub for Actions build

REPO_NAME="ios-antiscreen"
GITHUB_USER="YOUR_GITHUB_USERNAME"

echo "[+] Setting up GitHub repo..."

# Init git
git init
git add .
git commit -m "Initial commit: iOS Antiscreen App"

# Create repo on GitHub (requires gh CLI or manual)
echo "[*] Create repo at: https://github.com/new"
echo "[*] Repo name: $REPO_NAME"
echo "[*] Then run:"
echo "    git remote add origin https://github.com/$GITHUB_USER/$REPO_NAME.git"
echo "    git push -u origin main"

echo "[+] Local git repo ready"
