#!/bin/bash
# 本地快速构建 IPA (需要 macOS)

set -e

# 自动检测 Theos 路径
THEOS=${THEOS:-~/theos}

if [ ! -d "$THEOS" ]; then
    echo "ERROR: Theos not found at $THEOS"
    echo "Install: git clone https://github.com/theos/theos.git ~/theos"
    exit 1
fi

# 构建
make -C "$THEOS" -f "$THEOS/makefiles/package.mk" \
    THEOS_DEVICE_IP=localhost \
    THEOS_DEVICE_PORT=2222 \
    install

echo "[+] IPA built successfully"
echo "[*] Location: ~/theos/packages/com.antiscreen.app_1.0_iphoneos-arm64.deb"
echo "[*] Convert to IPA:"
echo "    cd ~/theos/packages"
echo "    mv com.antiscreen.app_1.0_iphoneos-arm64.deb Payload"
echo "    zip -qr Antiscreen.ipa Payload"
