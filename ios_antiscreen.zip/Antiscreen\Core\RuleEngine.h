#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, RuleType) {
    RuleTypeBlock = 0,
    RuleTypeRedirect = 1,
    RuleTypeProcessKill = 2,
    RuleTypeMemoryProtect = 3
};

@interface Rule : NSObject
@property (nonatomic, strong, readonly) NSString *name;
@property (nonatomic, strong, readonly) NSString *target;
@property (nonatomic, assign, readonly) RuleType type;
@property (nonatomic, strong, readonly, nullable) NSNumber *port;

- (instancetype)initWithName:(NSString *)name 
                       target:(NSString *)target 
                         type:(RuleType)type 
                         port:(nullable NSNumber *)port;
@end

/**
 * RuleEngine - 规则引擎
 * 对应 Android rulecore 的规则处理
 */
@interface RuleEngine : NSObject

+ (instancetype)shared;

// 默认规则
- (void)loadDefaultRules;

// 导入加密规则 (兼容 Android)
- (BOOL)importEncryptedRulesFrom:(NSData *)data key:(NSData *)key;

// 获取规则
- (NSArray<Rule *> *)getNetworkRules;
- (NSArray<Rule *> *)getProcessRules;
- (NSArray<Rule *> *)allRules;

// 解析规则
- (void)parseRulesFrom:(NSData *)data;

// 序列化规则
- (NSData *)serializeRules;

// 从 Android 导入的 JSON 格式
- (void)importFromJSON:(NSString *)jsonString;

@end

NS_ASSUME_NONNULL_END
