import NetworkExtension
import Foundation

class NetworkManager: ObservableObject {
    static let shared = NetworkManager()
    
    @Published var isConnected = false
    @Published var connectionStatus: NEVPNStatus = .invalid
    @Published var protectedProcesses: [String] = []
    
    private var vpnManager: NEVPNManager?
    private var dnsProxyManager: NEDNSProxyManager?
    
    // 从 Android 提取的规则模板
    private let blockedDomains = [
        "anticheatexpert.com",
        "anticheat.qq.com",
        "tenpay.com",
        "gcloud.tencent.com",
        "mazu.3g.qq.com",
        "monitor.uu.qq.com",
        "pingfore.qq.com",
        "tencent.com",
        // Valorant 相关
        "valorant-api.com",
        "riotgames.com",
    ]
    
    // 需要保护的进程列表
    private let targetProcesses = [
        "valorant",
        "com.riotgames.league",
        "com.riotgames.wildrift",
    ]
    
    init() {
        loadManager()
        setupObservers()
    }
    
    private func loadManager() {
        NETunnelProviderManager.loadAllFromPreferences { managers, error in
            if let manager = managers?.first {
                self.vpnManager = manager
                self.updateStatus(manager.connection.status)
            } else {
                self.createVPNConfiguration()
            }
        }
    }
    
    private func createVPNConfiguration() {
        let manager = NETunnelProviderManager()
        manager.localizedDescription = "防观察 VPN"
        
        let proto = NETunnelProviderProtocol()
        proto.providerBundleIdentifier = "com.antiscreen.app.networkextension"
        proto.serverAddress = "127.0.0.1"
        proto.providerConfiguration = [
            "blockedDomains": blockedDomains,
            "targetProcesses": targetProcesses,
        ]
        
        manager.protocolConfiguration = proto
        manager.isEnabled = true
        
        manager.saveToPreferences { error in
            if let error = error {
                print("保存配置失败: \(error)")
            } else {
                self.vpnManager = manager
                self.updateStatus(manager.connection.status)
            }
        }
    }
    
    private func setupObservers() {
        NotificationCenter.default.addObserver(
            forName: NSNotification.Name.NEVPNStatusDidChange,
            object: nil,
            queue: .main
        ) { notification in
            if let connection = notification.object as? NEVPNConnection {
                self.updateStatus(connection.status)
            }
        }
    }
    
    private func updateStatus(_ status: NEVPNStatus) {
        DispatchQueue.main.async {
            self.connectionStatus = status
            self.isConnected = (status == .connected)
        }
    }
    
    func requestPermission() {
        NETunnelProviderManager.loadAllFromPreferences { _, _ in }
    }
    
    func startVPN(completion: @escaping (Bool) -> Void) {
        guard let manager = vpnManager else {
            completion(false)
            return
        }
        
        do {
            try manager.connection.startVPNTunnel()
            
            // 同时启动 DNS 代理
            startDNSProxy()
            
            // 扫描并保护目标进程
            scanAndProtectProcesses()
            
            completion(true)
        } catch {
            print("启动 VPN 失败: \(error)")
            completion(false)
        }
    }
    
    func stopVPN(completion: @escaping (Bool) -> Void) {
        vpnManager?.connection.stopVPNTunnel()
        stopDNSProxy()
        completion(true)
    }
    
    // MARK: - DNS Proxy
    
    private func startDNSProxy() {
        NEDNSProxyManager.loadAllFromPreferences { managers, error in
            guard let manager = managers?.first else {
                self.createDNSProxyConfiguration()
                return
            }
            
            do {
                try manager.connection.start()
            } catch {
                print("启动 DNS 代理失败: \(error)")
            }
        }
    }
    
    private func createDNSProxyConfiguration() {
        let manager = NEDNSProxyManager()
        manager.localizedDescription = "防观察 DNS 代理"
        
        let proto = NEDNSProxyProviderProtocol()
        proto.providerBundleIdentifier = "com.antiscreen.app.dnsproxy"
        proto.serverAddress = "127.0.0.1"
        
        manager.providerProtocol = proto
        manager.isEnabled = true
        
        manager.saveToPreferences { error in
            if let error = error {
                print("保存 DNS 配置失败: \(error)")
            }
        }
    }
    
    private func stopDNSProxy() {
        NEDNSProxyManager.loadAllFromPreferences { managers, _ in
            managers?.first?.connection.stop()
        }
    }
    
    // MARK: - Process Protection
    
    private func scanAndProtectProcesses() {
        // 调用 native 层扫描进程
        let pids = ProcessScanner.findTargetProcesses(targetProcesses)
        DispatchQueue.main.async {
            self.protectedProcesses = pids.map { "PID: \($0)" }
        }
        
        // 对目标进程执行反调试
        for pid in pids {
            ProcessScanner.antiDebug(pid: pid)
        }
    }
}
