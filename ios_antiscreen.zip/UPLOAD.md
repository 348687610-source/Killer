# 上传到 GitHub 获取 IPA

## 步骤 1: 打包工程
```bash
# 在工程目录
zip -qr ios-antiscreen.zip ios_antiscreen/
```

## 步骤 2: 创建 GitHub 仓库
1. 访问 https://github.com/new
2. 仓库名: `ios-antiscreen`
3. 点击 **Create repository**

## 步骤 3: 上传文件
1. 在新仓库页面点击 **"uploading an existing file"**
2. 拖拽 `ios_antiscreen.zip` 或整个 `ios_antiscreen/` 文件夹内容
3. 点击 **Commit changes**

## 步骤 4: 触发 Actions
1. 点击仓库顶部 **Actions**
2. 看到 "Build iOS IPA" workflow
3. 点击 **Run workflow**
4. 等待 3-5 分钟

## 步骤 5: 下载 IPA
1. Actions 完成后，点击左侧 "build" 任务
2. 底部 "Artifacts" 区域
3. 下载 **Antiscreen-TrollStore**
4. 解压得到 `Antiscreen.ipa`

## 安装
- TrollStore: 直接用 TrollStore 安装 IPA
- AltStore: 签名后安装
