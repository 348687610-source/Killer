#import "ProcessScanner.h"
#import <mach/mach.h>
#import <mach/mach_init.h>
#import <mach/task.h>
#import <mach/thread_act.h>
#import <sys/sysctl.h>
#import <sys/proc_info.h>
#import <libproc.h>
#import <dlfcn.h>
#import <ptrace.h>

// 与 Android liblycore 对应的 iOS 实现
// 功能：进程扫描、注入、反调试、内存操作

@implementation ProcessScanner

#pragma mark - Process Enumeration

+ (NSArray<NSNumber *> *)findTargetProcesses:(NSArray<NSString *> *)targets {
    NSMutableArray<NSNumber *> *pids = [NSMutableArray array];
    
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t size;
    
    if (sysctl(mib, 4, NULL, &size, NULL, 0) < 0) {
        return @[];
    }
    
    struct kinfo_proc *procs = malloc(size);
    if (procs == NULL) {
        return @[];
    }
    
    if (sysctl(mib, 4, procs, &size, NULL, 0) < 0) {
        free(procs);
        return @[];
    }
    
    int count = (int)(size / sizeof(struct kinfo_proc));
    
    for (int i = 0; i < count; i++) {
        pid_t pid = procs[i].kp_proc.p_pid;
        if (pid == 0) continue;
        
        char pathbuf[PROC_PIDPATHINFO_MAXSIZE];
        if (proc_pidpath(pid, pathbuf, sizeof(pathbuf)) <= 0) {
            continue;
        }
        
        NSString *path = [NSString stringWithUTF8String:pathbuf];
        NSString *name = [[path lastPathComponent] lowercaseString];
        
        for (NSString *target in targets) {
            if ([name containsString:[target lowercaseString]]) {
                [pids addObject:@(pid)];
                NSLog(@"[ProcessScanner] Found target: %@ (PID: %d)", path, pid);
                break;
            }
        }
    }
    
    free(procs);
    return pids;
}

+ (NSArray<NSDictionary *> *)scanAllProcesses {
    NSMutableArray<NSDictionary *> *processes = [NSMutableArray array];
    
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t size;
    
    if (sysctl(mib, 4, NULL, &size, NULL, 0) < 0) {
        return @[];
    }
    
    struct kinfo_proc *procs = malloc(size);
    if (procs == NULL) return @[];
    
    if (sysctl(mib, 4, procs, &size, NULL, 0) < 0) {
        free(procs);
        return @[];
    }
    
    int count = (int)(size / sizeof(struct kinfo_proc));
    
    for (int i = 0; i < count; i++) {
        pid_t pid = procs[i].kp_proc.p_pid;
        if (pid <= 0) continue;
        
        char pathbuf[PROC_PIDPATHINFO_MAXSIZE];
        char namebuf[MAXCOMLEN + 1];
        
        proc_name(pid, namebuf, sizeof(namebuf));
        proc_pidpath(pid, pathbuf, sizeof(pathbuf));
        
        NSMutableDictionary *info = [@{
            @"pid": @(pid),
            @"name": [NSString stringWithUTF8String:namebuf] ?: @"unknown",
            @"path": [NSString stringWithUTF8String:pathbuf] ?: @""
        } mutableCopy];
        
        // 获取内存信息
        struct proc_taskinfo taskinfo;
        if (proc_pidinfo(pid, PROC_PIDTASKINFO, 0, &taskinfo, sizeof(taskinfo)) > 0) {
            info[@"resident_size"] = @(taskinfo.pti_resident_size);
            info[@"virtual_size"] = @(taskinfo.pti_virtual_size);
        }
        
        // 检测是否为调试器
        BOOL isDebugger = [self checkIfDebuggerAttached:pid];
        info[@"is_debugger"] = @(isDebugger);
        
        // 检测模块列表
        NSArray *modules = [self enumerateModules:pid];
        info[@"modules"] = modules;
        
        [processes addObject:info];
    }
    
    free(procs);
    return processes;
}

#pragma mark - Memory Operations (对应 lycore peek/poke)

+ (BOOL)peek:(pid_t)pid address:(vm_address_t)addr size:(vm_size_t)size buffer:(void **)buffer {
    task_t task;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) return NO;
    
    vm_size_t actualSize = size;
    void *data = NULL;
    
    kr = vm_read(task, addr, size, (vm_offset_t *)&data, &actualSize);
    mach_port_deallocate(mach_task_self(), task);
    
    if (kr == KERN_SUCCESS) {
        *buffer = data;
        return YES;
    }
    return NO;
}

+ (BOOL)poke:(pid_t)pid address:(vm_address_t)addr data:(void *)data size:(vm_size_t)size {
    task_t task;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) return NO;
    
    // 先解除保护
    vm_protect(task, addr, size, FALSE, VM_PROT_READ | VM_PROT_WRITE);
    
    kr = vm_write(task, addr, (vm_offset_t)data, size);
    mach_port_deallocate(mach_task_self(), task);
    
    return kr == KERN_SUCCESS;
}

+ (NSArray<NSDictionary *> *)scanMemory:(pid_t)pid pattern:(NSString *)pattern {
    NSMutableArray<NSDictionary *> *results = [NSMutableArray array];
    
    // 获取进程内存映射
    vm_address_t address = 0;
    vm_size_t size;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_BASIC_INFO_COUNT_64;
    memory_object_name_t object_name;
    
    task_t task;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) return @[];
    
    while (1) {
        kr = vm_region_64(task, &address, &size, VM_REGION_BASIC_INFO_64,
                          (vm_region_info_t)&info, &count, &object_name);
        if (kr != KERN_SUCCESS) break;
        
        // 只扫描可读写的内存区域
        if (info.protection & VM_PROT_READ) {
            void *data = NULL;
            if ([self peek:pid address:address size:size buffer:&data]) {
                // 在内存中搜索模式
                // 简化版：只添加区域信息
                [results addObject:@{
                    @"address": @(address),
                    @"size": @(size),
                    @"protection": @(info.protection)
                }];
                vm_deallocate(mach_task_self(), (vm_address_t)data, size);
            }
        }
        
        address += size;
    }
    
    mach_port_deallocate(mach_task_self(), task);
    return results;
}

#pragma mark - Module Enumeration

+ (NSArray<NSDictionary *> *)enumerateModules:(pid_t)pid {
    NSMutableArray<NSDictionary *> *modules = [NSMutableArray array];
    
    task_t task;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) return @[];
    
    vm_address_t address = 0;
    vm_size_t size;
    vm_region_basic_info_data_64_t info;
    mach_msg_type_number_t count = VM_REGION_BASIC_INFO_COUNT_64;
    memory_object_name_t object_name;
    
    while (1) {
        kr = vm_region_64(task, &address, &size, VM_REGION_BASIC_INFO_64,
                          (vm_region_info_t)&info, &count, &object_name);
        if (kr != KERN_SUCCESS) break;
        
        if (info.share_mode != SM_EMPTY) {
            [modules addObject:@{
                @"address": @(address),
                @"size": @(size),
                @"protection": [NSString stringWithFormat:@"%c%c%c",
                    (info.protection & VM_PROT_READ) ? 'r' : '-',
                    (info.protection & VM_PROT_WRITE) ? 'w' : '-',
                    (info.protection & VM_PROT_EXECUTE) ? 'x' : '-']
            }];
        }
        
        address += size;
    }
    
    mach_port_deallocate(mach_task_self(), task);
    return modules;
}

#pragma mark - Anti-Debug

+ (BOOL)antiDebug:(pid_t)pid {
    // 方法1: ptrace PT_DENY_ATTACH
    if (pid == getpid()) {
        ptrace(PT_DENY_ATTACH, 0, 0, 0);
    }
    
    // 方法2: 设置不能被调试标志
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, pid };
    struct kinfo_proc info;
    size_t size = sizeof(info);
    
    if (sysctl(mib, 4, &info, &size, NULL, 0) == 0) {
        // 检测是否已经被调试
        if (info.kp_proc.p_flag & P_TRACED) {
            NSLog(@"[AntiDebug] Process is being traced!");
            // 采取措施：可以尝试分离或终止
        }
    }
    
    // 方法3: 检测调试端口
    if ([self checkDebuggerPort]) {
        NSLog(@"[AntiDebug] Debugger port detected!");
    }
    
    return YES;
}

+ (BOOL)checkIfDebuggerAttached:(pid_t)pid {
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_PID, pid };
    struct kinfo_proc info;
    size_t size = sizeof(info);
    
    if (sysctl(mib, 4, &info, &size, NULL, 0) == 0) {
        return (info.kp_proc.p_flag & P_TRACED) != 0;
    }
    return NO;
}

+ (BOOL)checkDebuggerPort {
    // 检测是否有调试器连接
    struct kinfo_proc *procs;
    int mib[4] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0 };
    size_t size;
    
    sysctl(mib, 4, NULL, &size, NULL, 0);
    procs = malloc(size);
    sysctl(mib, 4, procs, &size, NULL, 0);
    
    int count = (int)(size / sizeof(struct kinfo_proc));
    BOOL found = NO;
    
    for (int i = 0; i < count; i++) {
        if (procs[i].kp_proc.p_pid == getppid()) {
            // 检查父进程是否是调试器
            char namebuf[MAXCOMLEN + 1];
            proc_name(procs[i].kp_proc.p_pid, namebuf, sizeof(namebuf));
            NSString *parentName = [NSString stringWithUTF8String:namebuf];
            if ([parentName containsString:@"debug"] || 
                [parentName containsString:@"lldb"] ||
                [parentName containsString:@"gdb"]) {
                found = YES;
            }
            break;
        }
    }
    
    free(procs);
    return found;
}

#pragma mark - Injection (对应 linjector)

+ (BOOL)injectTweak {
    // 检查越狱环境
    if (![self isJailbroken]) {
        NSLog(@"[Injector] Jailbreak not detected, injection unavailable");
        return NO;
    }
    
    // 加载动态库 (dlopen)
    NSString *tweakPath = @"/usr/lib/AntiscreenTweak.dylib";
    if (![[NSFileManager defaultManager] fileExistsAtPath:tweakPath]) {
        NSLog(@"[Injector] Tweak not found at %@", tweakPath);
        return NO;
    }
    
    void *handle = dlopen([tweakPath UTF8String], RTLD_LAZY);
    if (handle) {
        NSLog(@"[Injector] Tweak loaded successfully");
        
        // 调用初始化函数
        void (*init)(void) = dlsym(handle, "_antitweak_init");
        if (init) {
            init();
        }
        
        return YES;
    } else {
        NSLog(@"[Injector] Failed to load tweak: %s", dlerror());
        return NO;
    }
}

+ (BOOL)injectIntoProcess:(pid_t)pid tweakPath:(NSString *)path {
    // 需要 task_for_pid 权限
    task_t task;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) {
        NSLog(@"[Injector] Failed to get task port: %d", kr);
        return NO;
    }
    
    // 在目标进程中分配内存并写入 dylib 路径
    // 然后创建远程线程调用 dlopen
    
    // 简化实现：实际需要 Mach-O 注入技术
    // 参考 theos/insert_dylib 或 electra/substitute 的实现
    
    mach_port_deallocate(mach_task_self(), task);
    return YES;
}

#pragma mark - Jailbreak Detection

+ (BOOL)isJailbroken {
    // 常见越狱检测点
    NSArray *jailbreakFiles = @[
        @"/Applications/Cydia.app",
        @"/usr/sbin/sshd",
        @"/etc/apt",
        @"/usr/bin/ldid",
        @"/usr/sbin/frida-server"
    ];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    for (NSString *path in jailbreakFiles) {
        if ([fm fileExistsAtPath:path]) {
            return YES;
        }
    }
    
    // 尝试写入系统目录
    NSString *testPath = @"/private/jailbreak_test";
    if ([@"test" writeToFile:testPath atomically:YES encoding:NSUTF8StringEncoding error:nil]) {
        [[NSFileManager defaultManager] removeItemAtPath:testPath error:nil];
        return YES;
    }
    
    return NO;
}

#pragma mark - Process Control

+ (BOOL)killProcess:(pid_t)pid {
    return kill(pid, SIGKILL) == 0;
}

+ (BOOL)suspendProcess:(pid_t)pid {
    return kill(pid, SIGSTOP) == 0;
}

+ (BOOL)resumeProcess:(pid_t)pid {
    return kill(pid, SIGCONT) == 0;
}

+ (BOOL)killDirectory:(NSString *)path {
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (![fm fileExistsAtPath:path]) {
        return NO;
    }
    
    // 递归删除目录
    NSError *error;
    NSArray *contents = [fm contentsOfDirectoryAtPath:path error:&error];
    
    for (NSString *item in contents) {
        NSString *fullPath = [path stringByAppendingPathComponent:item];
        [fm removeItemAtPath:fullPath error:&error];
    }
    
    return YES;
}

#pragma mark - Environment Hardening

+ (BOOL)hardenEnvironment {
    // 清理环境变量
    unsetenv("DYLD_INSERT_LIBRARIES");
    unsetenv("DYLD_LIBRARY_PATH");
    unsetenv("DYLD_FRAMEWORK_PATH");
    
    // 设置防护标志
    setenv("_MALLOC_SCRIBBLE", "1", 1);
    setenv("_MALLOC_FILL_SPACE", "1", 1);
    
    // 禁用某些系统调试功能
    setenv("MallocGuardEdges", "1", 1);
    
    return YES;
}

@end
