#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

/**
 * ProcessScanner - iOS 进程扫描与保护框架
 * 对应 Android liblycore 的核心功能
 */
@interface ProcessScanner : NSObject

// MARK: - Process Discovery

/**
 * 查找目标进程
 * @param targets 目标进程名称列表
 * @return 匹配的 PID 数组
 */
+ (NSArray<NSNumber *> *)findTargetProcesses:(NSArray<NSString *> *)targets;

/**
 * 扫描所有进程
 * @return 进程信息字典数组，包含 PID、名称、路径、内存等
 */
+ (NSArray<NSDictionary *> *)scanAllProcesses;

// MARK: - Memory Operations (对应 lycore peek/poke)

/**
 * 读取目标进程内存
 * @param pid 目标进程 PID
 * @param addr 目标地址
 * @param size 读取大小
 * @param buffer 输出缓冲区
 * @return 是否成功
 */
+ (BOOL)peek:(pid_t)pid address:(vm_address_t)addr size:(vm_size_t)size buffer:(void **)buffer;

/**
 * 写入目标进程内存
 * @param pid 目标进程 PID
 * @param addr 目标地址
 * @param data 数据指针
 * @param size 数据大小
 * @return 是否成功
 */
+ (BOOL)poke:(pid_t)pid address:(vm_address_t)addr data:(void *)data size:(vm_size_t)size;

/**
 * 扫描内存
 * @param pid 目标进程 PID
 * @param pattern 搜索模式
 * @return 匹配结果数组
 */
+ (NSArray<NSDictionary *> *)scanMemory:(pid_t)pid pattern:(NSString *)pattern;

// MARK: - Module Enumeration

/**
 * 枚举进程加载的模块
 * @param pid 目标进程 PID
 * @return 模块信息数组
 */
+ (NSArray<NSDictionary *> *)enumerateModules:(pid_t)pid;

// MARK: - Anti-Debug

/**
 * 启用反调试保护
 * @param pid 进程 PID（0 表示当前进程）
 * @return 是否成功
 */
+ (BOOL)antiDebug:(pid_t)pid;

/**
 * 检查进程是否被调试
 * @param pid 进程 PID
 * @return 是否被调试
 */
+ (BOOL)checkIfDebuggerAttached:(pid_t)pid;

/**
 * 检测调试端口
 * @return 是否检测到调试器
 */
+ (BOOL)checkDebuggerPort;

// MARK: - Injection (对应 linjector)

/**
 * 注入 tweak dylib
 * @return 是否成功
 */
+ (BOOL)injectTweak;

/**
 * 注入指定进程
 * @param pid 目标进程 PID
 * @param path dylib 路径
 * @return 是否成功
 */
+ (BOOL)injectIntoProcess:(pid_t)pid tweakPath:(NSString *)path;

// MARK: - Jailbreak Detection

/**
 * 检测越狱环境
 * @return 是否越狱
 */
+ (BOOL)isJailbroken;

// MARK: - Process Control

/**
 * 终止进程
 * @param pid 进程 PID
 * @return 是否成功
 */
+ (BOOL)killProcess:(pid_t)pid;

/**
 * 暂停进程
 * @param pid 进程 PID
 * @return 是否成功
 */
+ (BOOL)suspendProcess:(pid_t)pid;

/**
 * 恢复进程
 * @param pid 进程 PID
 * @return 是否成功
 */
+ (BOOL)resumeProcess:(pid_t)pid;

/**
 * 清理目录
 * @param path 目录路径
 * @return 是否成功
 */
+ (BOOL)killDirectory:(NSString *)path;

// MARK: - Environment Hardening

/**
 * 加固运行环境
 * 清理 DYLD 相关环境变量，设置防护标志
 * @return 是否成功
 */
+ (BOOL)hardenEnvironment;

@end

NS_ASSUME_NONNULL_END
