#!/bin/bash
# iOS 巨魔版构建脚本 (Mac/Linux)

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
IPA_DIR="$PROJECT_DIR"

# 需要替换为你的开发者证书
DEVELOPER_ID="YOUR_DEVELOPER_ID"
BUNDLE_ID="com.antiscreen.app"

# 清理
echo "[+] Cleaning..."
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

# 构建主 App
echo "[+] Building Antiscreen..."
cd "$PROJECT_DIR/Antiscreen.xcodeproj"

# Release 构建
xcodebuild -project "$PROJECT_DIR/Antiscreen.xcodeproj" \
    -scheme Antiscreen \
    -configuration Release \
    -derivedDataPath "$BUILD_DIR" \
    CODE_SIGN_IDENTITY="$DEVELOPER_ID" \
    PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
    build

# 导出
echo "[+] Exporting..."
APP_PATH="$BUILD_DIR/Build/Products/Release-iphoneos/Antiscreen.app"
PAYLOAD_DIR="$BUILD_DIR/Payload"

mkdir -p "$PAYLOAD_DIR"
cp -R "$APP_PATH" "$PAYLOAD_DIR/Antiscreen.app"

# 巨魔签名 (使用 ldid)
if command -v ldid &> /dev/null; then
    echo "[+] Signing with ldid (TrollStore)..."
    ldid -S"$PROJECT_DIR/Antiscreen/Antiscreen/Antiscreen.entitlements" \
        "$PAYLOAD_DIR/Antiscreen.app/Antiscreen"
else
    echo "[!] ldid not found, using codesign..."
    codesign -f -s "$DEVELOPER_ID" --entitlements \
        "$PROJECT_DIR/Antiscreen/Antiscreen/Antiscreen.entitlements" \
        "$PAYLOAD_DIR/Antiscreen.app/Antiscreen"
fi

# 打包 IPA
echo "[+] Creating IPA..."
cd "$BUILD_DIR"
zip -qr "$IPA_DIR/Antiscreen.ipa" Payload/

echo "[+] Done!"
echo "[*] IPA: $IPA_DIR/Antiscreen.ipa"
echo "[*] Install with TrollStore or AltStore"
