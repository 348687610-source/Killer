#!/bin/bash
# iOS 防观察 App 构建脚本 (巨魔/侧载版)

set -e

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="$PROJECT_DIR/build"
IPA_DIR="$PROJECT_DIR/ipa"

echo "[+] Building iOS Antiscreen App"
echo "[*] Project: $PROJECT_DIR"

# 清理
rm -rf "$BUILD_DIR" "$IPA_DIR"
mkdir -p "$BUILD_DIR" "$IPA_DIR"

# 创建 Payload 结构
echo "[+] Creating Payload structure"
mkdir -p "$BUILD_DIR/Payload/Antiscreen.app"

# 复制资源
echo "[+] Copying resources"
cp -r "$PROJECT_DIR/Antiscreen/Antiscreen"/* "$BUILD_DIR/Payload/Antiscreen.app/" 2>/dev/null || true
cp "$PROJECT_DIR/Antiscreen/Antiscreen/Info.plist" "$BUILD_DIR/Payload/Antiscreen.app/"

# 复制 entitlements (巨魔需要)
echo "[+] Setting up entitlements"
cp "$PROJECT_DIR/Antiscreen/Antiscreen.entitlements" "$BUILD_DIR/Payload/Antiscreen.app/embedded.mobileprovision" 2>/dev/null || true

# 创建默认的 App Icon (如果存在)
if [ -f "$PROJECT_DIR/Assets/AppIcon.png" ]; then
    cp "$PROJECT_DIR/Assets/AppIcon.png" "$BUILD_DIR/Payload/Antiscreen.app/AppIcon60x60@2x.png"
    cp "$PROJECT_DIR/Assets/AppIcon.png" "$BUILD_DIR/Payload/Antiscreen.app/AppIcon60x60@3x.png"
fi

# 设置权限
echo "[+] Setting permissions"
chmod -R 755 "$BUILD_DIR/Payload"

# 创建 IPA
echo "[+] Creating IPA"
cd "$BUILD_DIR"
zip -qr "$IPA_DIR/Antiscreen.ipa" Payload/

echo "[+] Build complete!"
echo "[*] IPA location: $IPA_DIR/Antiscreen.ipa"
echo "[*] Install with TrollStore or AltStore"
