import Foundation

@objc class RuleEngine: NSObject {
    static let shared = RuleEngine()
    
    private var rules: [Rule] = []
    private var envelopeKey: Data?
    
    // 兼容 Android rulecore 的规则 envelope
    // envelope 格式：[magic:4][version:2][encrypted_len:4][hmac:32][encrypted_payload:N]
    private let envelopeMagic: UInt32 = 0xDEADBEEF
    
    private override init() {
        super.init()
        loadDefaultRules()
    }
    
    // MARK: - Rule Management
    
    func loadDefaultRules() {
        // 从 Android 提取的默认规则
        let defaultRules: [Rule] = [
            // 网络过滤
            Rule(name: "Block Anti-Cheat", target: "anticheatexpert.com", type: .block, port: 443),
            Rule(name: "Block Tencent Monitor", target: "pingfore.qq.com", type: .block, port: 443),
            Rule(name: "Block Valorant API", target: "valorant-api.com", type: .block, port: 443),
            Rule(name: "Block Riot Games", target: "riotgames.com", type: .block, port: 443),
            Rule(name: "Block Tencent Cloud", target: "gcloud.tencent.com", type: .block, port: 443),
            Rule(name: "Block QQ Monitor", target: "mazu.3g.qq.com", type: .block, port: 443),
            Rule(name: "Block UU Accelerator", target: "monitor.uu.qq.com", type: .block, port: 443),
            Rule(name: "Redirect DNS", target: "127.0.0.1", type: .redirect, port: 53),
            
            // 进程屏蔽
            Rule(name: "Block ACE Guard", target: "ace-guard", type: .processKill, port: nil),
            Rule(name: "Block Tenprotect", target: "tenprotect", type: .processKill, port: nil),
            Rule(name: "Block GameDetect", target: "gamedetect", type: .processKill, port: nil),
            Rule(name: "Block Observer", target: "observer", type: .processKill, port: nil),
            
            // 内存保护
            Rule(name: "Protect Anti-Cheat Memory", target: "com.riotgames", type: .memoryProtect, port: nil),
        ]
        
        rules = defaultRules
    }
    
    // MARK: - Encrypted Rule Import (兼容 Android)
    
    func importEncryptedRules(from data: Data, key: Data) -> Bool {
        guard data.count > 40 else { return false }
        
        // Parse envelope header
        let magic = data.withUnsafeBytes { $0.loadUnaligned(as: UInt32.self) }
        guard magic == envelopeMagic else { return false }
        
        let version = data.withUnsafeBytes { 
            $0.load(fromByteOffset: 4, as: UInt16.self) 
        }
        
        let encryptedLen = data.withUnsafeBytes {
            $0.load(fromByteOffset: 6, as: UInt32.self)
        }
        
        guard encryptedLen > 0 && encryptedLen < UInt32(data.count) else { return false }
        
        let encryptedPayload = data.subdata(in: 12..<(12 + Int(encryptedLen)))
        let hmac = data.subdata(in: (12 + Int(encryptedLen))..<data.count)
        
        // Verify HMAC
        let computedHMAC = HMAC.sha256(data: encryptedPayload, key: key)
        guard hmac == computedHMAC else { return false }
        
        // Decrypt (AES-256-CBC)
        guard let decrypted = decryptAES(data: encryptedPayload, key: key) else {
            return false
        }
        
        // Parse rules from decrypted data
        parseRules(from: decrypted)
        return true
    }
    
    private func parseRules(from data: Data) {
        // 解析规则 JSON 或二进制格式
        guard let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let ruleArray = json["rules"] as? [[String: Any]] else {
            return
        }
        
        rules = ruleArray.compactMap { dict in
            guard let name = dict["name"] as? String,
                  let target = dict["target"] as? String,
                  let typeStr = dict["type"] as? String else { return nil }
            
            let type: RuleType
            switch typeStr {
            case "block": type = .block
            case "redirect": type = .redirect
            case "process_kill": type = .processKill
            case "memory_protect": type = .memoryProtect
            default: type = .block
            }
            
            let port = dict["port"] as? Int
            return Rule(name: name, target: target, type: type, port: port)
        }
    }
    
    // MARK: - Rule Access
    
    func getNetworkRules() -> [Rule] {
        return rules.filter { $0.type == .block || $0.type == .redirect }
    }
    
    func getProcessRules() -> [Rule] {
        return rules.filter { $0.type == .processKill || $0.type == .memoryProtect }
    }
    
    func allRules() -> [Rule] {
        return rules
    }
    
    // MARK: - Crypto
    
    private func decryptAES(data: Data, key: Data) -> Data? {
        // AES-256-CBC decryption
        // 使用 CommonCrypto
        var keyBytes = [UInt8](repeating: 0, count: kCCKeySizeAES256)
        data.copyBytes(to: &keyBytes, count: min(data.count, kCCKeySizeAES256))
        
        var iv = [UInt8](repeating: 0, count: kCCBlockSizeAES128)
        var outLength = 0
        var output = [UInt8](repeating: 0, count: data.count)
        
        let status = CCCrypt(
            CCOperation(kCCDecrypt),
            CCAlgorithm(kCCAlgorithmAES),
            CCOptions(kCCOptionPKCS7Padding),
            &keyBytes,
            kCCKeySizeAES256,
            &iv,
            Array(data),
            data.count,
            &output,
            data.count,
            &outLength
        )
        
        guard status == kCCSuccess else { return nil }
        return Data(bytes: output, count: outLength)
    }
    
    private func hexString(from data: Data) -> String {
        return data.map { String(format: "%02x", $0) }.joined()
    }
}

// MARK: - Rule Model

@objc enum RuleType: Int {
    case block = 0
    case redirect = 1
    case processKill = 2
    case memoryProtect = 3
}

@objc class Rule: NSObject {
    let name: String
    let target: String
    let type: RuleType
    let port: Int?
    
    init(name: String, target: String, type: RuleType, port: Int? = nil) {
        self.name = name
        self.target = target
        self.type = type
        self.port = port
    }
}

// MARK: - Crypto Helper

import CommonCrypto

struct HMAC {
    static func sha256(data: Data, key: Data) -> Data {
        var mac = [UInt8](repeating: 0, count: Int(CC_SHA256_DIGEST_LENGTH))
        data.withUnsafeBytes { dataBytes in
            key.withUnsafeBytes { keyBytes in
                CCHmac(CCHmacAlgorithm(kCCHmacAlgSHA256),
                       keyBytes.baseAddress,
                       key.count,
                       dataBytes.baseAddress,
                       data.count,
                       &mac)
            }
        }
        return Data(mac)
    }
}

import CommonCrypto
